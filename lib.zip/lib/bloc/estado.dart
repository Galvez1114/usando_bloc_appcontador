class Estado {
  final int numero;
  Estado({required this.numero});
}
